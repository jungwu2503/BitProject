package bitedu.bipa.test.utils;

import java.sql.*;

import javax.naming.*;
import javax.sql.*;

public class ConnectionManager {
	private static ConnectionManager manager;
	
	private ConnectionManager() {}
	
	public static ConnectionManager getInstance() {
		if(manager==null) {
			manager = new ConnectionManager();
		}
		return manager;
	}
	public Connection getConnection() {
		Connection con = null;
		try {
			Context ctx = (Context)new InitialContext();
			Context env = (Context)ctx.lookup("java:/comp/env");
			DataSource ds = (DataSource)env.lookup("jdbc/test");
			con = ds.getConnection();
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return con;
	}
	
	public void closeConnection(ResultSet rs , Statement stmt, Connection con) {
		if(rs!=null) {
			try {
				rs.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(stmt!=null) {
			try {
				stmt.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		
		if(con!=null) {
			try {
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		} else {
			con = null;
		}
	}
}
