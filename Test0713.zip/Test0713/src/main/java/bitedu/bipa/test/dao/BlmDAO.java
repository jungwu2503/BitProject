package bitedu.bipa.test.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.sql.DataSource;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bitedu.bipa.test.vo.BookCopy;

@Repository("blmDAO")
public class BlmDAO {
	
	@Autowired
	private SqlSession sqlSession;
	
	public boolean insertBook(BookCopy copy){
		boolean flag = false;
		
		int affectedCount1 = sqlSession.insert("mapper.book.insertBook", copy);
		int affectedCount2 = sqlSession.insert("mapper.book.insertCopy", copy.getIsbn());
		if (affectedCount1 > 0 && affectedCount2 > 0) {
			flag = true;
		}
		
		return flag;
	}
	
	public ArrayList<BookCopy> selectBookAll(){
		ArrayList<BookCopy> list = null;
		list = (ArrayList)sqlSession.selectList("mapper.book.selectAllBook");
		System.out.println(list.size());
		
		return list;
	}
	public boolean deleteBook(int parseInt) {
		boolean flag = false;
		
		int affectedCount = sqlSession.delete("mapper.book.deleteBook", parseInt);
		if (affectedCount > 0) {
			flag = true;
		}
		
		return flag;
	}
	public BookCopy selectBook(int parseInt) {
		BookCopy copy = null;
		copy = sqlSession.selectOne("mapper.book.selectBookBySeq",parseInt);
		
		return copy;
	}
	public boolean updateBook(BookCopy copy) {
		boolean flag = false;
		
		int affectedCount = sqlSession.update("mapper.book.updateBook", copy);
		if (affectedCount>0) {
			flag = true;
		}
		
		return flag;
	}
}







