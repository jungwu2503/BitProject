package bitedu.bipa.member.controller;

public class AjaxDAO {

	public boolean checkId(String id) {
		boolean flag = false;
		
		if (!id.equals("admin")) flag = true;
		
		return flag;
	}
	
}
