package bitedu.bipa.member.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class MemberController extends HttpServlet {
	AjaxDAO dao;
	MemberController() {
		dao = new AjaxDAO();
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
	}
	
	public boolean idcheck(HttpServletRequest req, HttpServletResponse resp) {
		String id = req.getParameter("user_id");
		resp.setContentType("text/html; charset=UTF-8");
		
		return dao.checkId(id);
	}
}
