import java.io.IOException;
import java.sql.*;
import java.util.*;

public class UserDAO {

	public ArrayList<UserDTO> getUserInfo(String userId) throws IOException {
		ArrayList<UserDTO> list = new ArrayList<UserDTO>();
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "Select * from UserTable";
		
		try {
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			while (rs.next()) {
				UserDTO dto = new UserDTO(rs.getString(1), rs.getInt(2), rs.getString(3));
				
				list.add(dto);
			}
			
			ConnectionManager.closeConnection(rs, pstmt, con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
			
		return list;
	}
	
}
