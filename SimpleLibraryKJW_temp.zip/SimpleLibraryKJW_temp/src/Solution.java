import java.io.*;
import java.util.*;

import org.json.simple.*;

public class Solution {
	UserService us;
	ArrayList<UserDTO> dtoList;
	
	public Solution() {
		us = new UserService();
		dtoList = new ArrayList<UserDTO>();
	}

	public static void main(String[] args) {
		Solution solution = new Solution();
		solution.getUserInfo("user1");
	}

	public void getUserInfo(String userId) {
		dtoList = us.getUserInfo(userId);
	}
	
	public void saveUserInfo(String userId, String userInfo) throws IOException {
		if (dtoList != null) {
			makeJSONFile(dtoList);
		}
	}
	
	public void makeJSONFile(ArrayList<UserDTO> dtoList) {
		JSONArray jsonArray = new JSONArray();
		
		for (int i = 0; i < dtoList.size(); i++) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("userName", dtoList.get(i).getUserName());
			jsonObject.put("userNumber", "" + dtoList.get(i).getUserNumber());
			jsonObject.put("userPhone", dtoList.get(i).getUserPhoneNumber());
		}
		
		System.out.println(jsonArray);
		
		FileWriter fw;
		try {
			fw = new FileWriter("C:\\Users\\jungw\\bipa_eclipse-workspace\\Test\\data\\test.json");
			fw.write(jsonArray.toJSONString());
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
