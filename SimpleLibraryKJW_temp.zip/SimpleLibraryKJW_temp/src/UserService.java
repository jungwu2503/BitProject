
import java.io.IOException;
import java.util.*;

public class UserService {
	UserDAO dao;
	ArrayList<UserDTO> dtoList;
	
	public UserService() {
		dao = new UserDAO();
		dtoList = new ArrayList<UserDTO>();
	}
	
	public ArrayList<UserDTO> getUserInfo(String userId) {
		try {
			dtoList = dao.getUserInfo(userId);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return dtoList;
	}
	
}