import java.util.*;

public class UserDTO {
	private String userName;
	private int userNumber;
	private String userPhoneNumber;
	private ArrayList<BookDTO> burrowedList; // DTO or bookName
	
	public UserDTO(String userName, int userNumber, String userPhoneNumber) {
		super();
		this.userName = userName;
		this.userNumber = userNumber;
		this.userPhoneNumber = userPhoneNumber;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getUserNumber() {
		return userNumber;
	}

	public void setUserNumber(int userNumber) {
		this.userNumber = userNumber;
	}

	public String getUserPhoneNumber() {
		return userPhoneNumber;
	}

	public void setUserPhoneNumber(String userPhoneNumber) {
		this.userPhoneNumber = userPhoneNumber;
	}
		
	public void burrowBook(BookDTO bookDTO) { 
		burrowedList.add(bookDTO);
	}
	
	public void returnBook(BookDTO bookDTO) {
		burrowedList.remove(bookDTO);
	}

	public ArrayList<BookDTO> getBurrowedList() {
		return burrowedList;
	}

	public void setBurrowedList(ArrayList<BookDTO> burrowedList) {
		this.burrowedList = burrowedList;
	}
	
}
