import java.io.*;
import java.sql.*;
import java.util.*;

public class LibraryDAO {
	
	public boolean executeBurrow(String bookName) throws IOException {
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "Select " + bookName + " from BookTable";
		boolean burrowFlag = false;
		
		try {
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				BookDTO dto = new BookDTO(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getString(5), rs.getString(6));
				
				if (dto.getState().equals("Burrowed")) continue;
				else if (dto.getState().equals("Returned")) {
					changeBookState(dto);
					changeBookStateInSQL(dto, con, pstmt, rs);
					burrowFlag = true;
					break;
				}
			}			
			ConnectionManager.closeConnection(rs, pstmt, con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
			
		return burrowFlag;
	}
	
	public void changeBookState(BookDTO dto) {
		String s = (dto.getState().equals("Burrowed") ? "Returned" : "Burrowed");
		dto.setState(s);
	}
	
	public void changeBookStateInSQL(BookDTO dto, Connection con, PreparedStatement pstmt, ResultSet rs) throws SQLException {
		String sql = "Update BookTable set bookNumber = ?, bookName = ?, author = ?, burrowDate = ?, returnDate = ?, state = ?";
		pstmt = con.prepareStatement(sql);
		pstmt.setInt(1, dto.getBookNumber());
		pstmt.setString(2, dto.getBookName());
		pstmt.setString(3, dto.getAuthor());
		pstmt.setString(4, dto.getBurrowDate());
		pstmt.setString(5, dto.getReturnDate());
		pstmt.setString(6, dto.getState());
	}
	
	public boolean executeReturn(UserDTO userDTO) throws SQLException, IOException {
		ArrayList<BookDTO> burrowedList = userDTO.getBurrowedList();
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		if (burrowedList.size() > 0) {
			BookDTO bookDTO = burrowedList.get(0); // �̱���, ����Ʈ �Ǿտ� �ݳ��� å �ִٰ� ����
			
			changeBookState(bookDTO);
			changeBookStateInSQL(bookDTO, con, pstmt, rs);
			
			return true;
		}
		
		System.out.println("���� å ����");
		return false;
	}
	
}
