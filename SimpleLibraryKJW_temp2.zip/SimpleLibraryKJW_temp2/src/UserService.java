
import java.io.IOException;
import java.util.*;

public class UserService {
	private UserDAO dao;
	private ArrayList<UserDTO> dtoList;
	
	public UserService() {
		dao = new UserDAO();
		dtoList = new ArrayList<UserDTO>();
	}
	
	public ArrayList<UserDTO> getUserInfo(String userId) {
		try {
			dtoList = dao.getUserInfo(userId);
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		return dtoList;
	}
	
	public void makeJSONFile(ArrayList<UserDTO> dtoList) {
		dao.makeJSONFile(dtoList);
	}
	
}