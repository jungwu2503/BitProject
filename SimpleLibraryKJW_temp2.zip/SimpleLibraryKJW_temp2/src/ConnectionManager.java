import java.io.*;
import java.sql.*;
import java.util.*;

public class ConnectionManager {
	public static void closeConnection(ResultSet rs, Statement stmt, Connection con) throws SQLException {
		if (rs != null) {
			rs.close();
		}
		rs = null;
		if (stmt != null) {
			stmt.close();
		}
		stmt = null;
		if (con != null) {
			con.close();
		}
		con = null;
	}
	
	public static Connection getConnection() throws IOException {
		Connection con = null;
		ArrayList<String> list = new ArrayList<String>();
		
		try {
			BufferedReader br = new BufferedReader(new FileReader(new File("C:\\Users\\jungw\\bipa_eclipse-workspace\\SimpleLibraryKJW_temp\\data\\db\\properties")));
			
			String line;
			StringTokenizer st;
			while ((line = br.readLine()) != null) {
				st = new StringTokenizer(line, "=");
				
				st.nextToken();
				list.add(st.nextToken());				
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		String jdbcURL = list.get(0);
		String driver = list.get(1);
		String id = list.get(2);
		String password = list.get(3);
		
		try {
			Class.forName(driver);
			con = DriverManager.getConnection(jdbcURL, id, password);
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		
		return con;
	}
}
