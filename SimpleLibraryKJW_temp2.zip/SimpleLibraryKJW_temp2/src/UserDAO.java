import java.io.*;
import java.sql.*;
import java.util.*;

import org.json.simple.*;

public class UserDAO {

	public ArrayList<UserDTO> getUserInfo(String userId) throws IOException {
		ArrayList<UserDTO> list = new ArrayList<UserDTO>();
		Connection con = ConnectionManager.getConnection();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		String sql = "Select * from UserTable";
		
		try {
			pstmt = con.prepareStatement(sql);
			
			rs = pstmt.executeQuery();
			while (rs.next()) {
				UserDTO dto = new UserDTO(rs.getString(1), rs.getInt(2), rs.getString(3));
				
				list.add(dto);
			}
			
			ConnectionManager.closeConnection(rs, pstmt, con);
		} catch (SQLException e) {
			e.printStackTrace();
		}
			
		return list;
	}
	
	public void makeJSONFile(ArrayList<UserDTO> dtoList) {
		JSONArray jsonArray = new JSONArray();
		
		for (int i = 0; i < dtoList.size(); i++) {
			JSONObject jsonObject = new JSONObject();
			jsonObject.put("userName", dtoList.get(i).getUserName());
			jsonObject.put("userNumber", "" + dtoList.get(i).getUserNumber());
			jsonObject.put("userPhone", dtoList.get(i).getUserPhoneNumber());
		}
		
		System.out.println(jsonArray);
		
		FileWriter fw;
		try {
			fw = new FileWriter("C:\\Users\\jungw\\bipa_eclipse-workspace\\Test\\data\\test.json");
			fw.write(jsonArray.toJSONString());
			fw.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
}
