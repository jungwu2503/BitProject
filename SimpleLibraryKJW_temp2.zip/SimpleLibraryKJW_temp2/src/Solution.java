import java.io.*;
import java.sql.SQLException;
import java.util.*;

public class Solution {
	UserService us;
	LibraryService ls;
	ArrayList<UserDTO> dtoList;
	
	public Solution() {
		us = new UserService();
		ls = new LibraryService();
		dtoList = new ArrayList<UserDTO>();
	}

	public static void main(String[] args) throws IOException, SQLException {
		Solution solution = new Solution();
		solution.getUserInfo("user1");
	}

	public void getUserInfo(String userId) throws IOException, SQLException {
		dtoList = us.getUserInfo(userId);
		
//		if (dtoList != null) {
//			try {
//				saveUserInfo(dtoList);
//			} catch (IOException e) {
//				e.printStackTrace();
//			}
//		}
		
		ls.executeLibraryService(dtoList.get(0)); // User ã�� �̱���
	}
	
//	public void saveUserInfo(String userId, String userInfo) throws IOException {
//		if (dtoList != null) {
//			us.makeJSONFile(dtoList);
//		}
//	}
	
	public void saveUserInfo(ArrayList<UserDTO> dtoList) throws IOException {
		if (dtoList != null) {
			us.makeJSONFile(dtoList);
		}
	}
	
}
