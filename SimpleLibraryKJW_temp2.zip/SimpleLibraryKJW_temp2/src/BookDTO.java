
public class BookDTO {
	private int bookNumber;
	private String bookName;
	private String author;
	private String burrowDate;
	private String returnDate;
	private String state;
	
	public BookDTO(int bookNumber, String bookName, String author, String burrowDate, String returnDate, String state) {
		super();
		this.bookNumber = bookNumber;
		this.bookName = bookName;
		this.author = author;
		this.burrowDate = burrowDate;
		this.returnDate = returnDate;
		this.state = state;
	}

	public int getBookNumber() {
		return bookNumber;
	}

	public void setBookNumber(int bookNumber) {
		this.bookNumber = bookNumber;
	}

	public String getBookName() {
		return bookName;
	}

	public void setBookName(String bookName) {
		this.bookName = bookName;
	}

	public String getAuthor() {
		return author;
	}

	public void setAuthor(String author) {
		this.author = author;
	}

	public String getBurrowDate() {
		return burrowDate;
	}

	public void setBurrowDate(String burrowDate) {
		this.burrowDate = burrowDate;
	}

	public String getReturnDate() {
		return returnDate;
	}

	public void setReturnDate(String returnDate) {
		this.returnDate = returnDate;
	}
	
	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}
	
}
