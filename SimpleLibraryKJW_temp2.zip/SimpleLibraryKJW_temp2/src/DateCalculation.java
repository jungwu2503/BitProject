import java.util.*;

public class DateCalculation {
//	private Date date;

//	public Date convertDate(String strDate) {

//	}
}
