package bitedu.bipa.tiles.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bitedu.bipa.tiles.dao.BookDAO;
import bitedu.bipa.tiles.vo.BookCopy;

@Service("bookService")
public class BookService {
	
	@Autowired
	private BookDAO bookDAO;
	
	public ArrayList<BookCopy> searchBookAll() {
		ArrayList<BookCopy> list = bookDAO.selectBookAll();
		
		return list;
	}
	
}
