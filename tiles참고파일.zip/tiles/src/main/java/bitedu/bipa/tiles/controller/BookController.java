package bitedu.bipa.tiles.controller;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import bitedu.bipa.tiles.service.BookService;
import bitedu.bipa.tiles.vo.BookCopy;
import bitedu.bipa.tiles.vo.User;

@Controller("bookController")
@RequestMapping("/book")
public class BookController {
	
	@Autowired
	private BookService bookService;

	@RequestMapping("/list.do")
	public ModelAndView list(HttpSession session) {
		ModelAndView mav = null;
		mav = new ModelAndView();
		String url = "/book/bookList";
		User user = (User)session.getAttribute("user");
		
		ArrayList<BookCopy> list = bookService.searchBookAll();
		if(user.getUserId().equals("admin")) {
			mav.addObject("list", list);
		} else {
			url = "/member/loginForm";
			mav.addObject("data","관리자가 아닙니다.");
		}
		mav.setViewName(url);

		return mav;
	}
	
	
//	@RequestMapping("/list.do")
//	public ModelAndView list(HttpSession session) {
//		ModelAndView mav = null;
//		mav = new ModelAndView();
//		String url = "/book/bookList";
//		User user = (User)session.getAttribute("user");
//		
//		ArrayList<BookCopy> list = bookService.searchBookAll();
//		if(user.getUserId().equals("admin")) {
//			mav.addObject("data", list);
//		} else {
//			url = "/member/loginForm";
//			mav.addObject("data","관리자가 아닙니다.");
//		}
//		mav.setViewName(url);
//
//		return mav;
//	}
}
