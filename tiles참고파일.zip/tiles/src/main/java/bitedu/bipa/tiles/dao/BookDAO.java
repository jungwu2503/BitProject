package bitedu.bipa.tiles.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bitedu.bipa.tiles.vo.BookCopy;

@Repository("bookDAO")
public class BookDAO {

	@Autowired
	private SqlSession sqlSession;
	
	public ArrayList<BookCopy> selectBookAll() {
		ArrayList<BookCopy> list = (ArrayList)sqlSession.selectList("mapper.book.selectAllBook");
		
		return list;
	}

}
