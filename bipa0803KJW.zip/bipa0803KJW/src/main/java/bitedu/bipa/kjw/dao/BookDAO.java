package bitedu.bipa.kjw.dao;

import java.util.ArrayList;
import java.util.HashMap;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bitedu.bipa.kjw.vo.BookCopy;

@Repository("bookDAO")
public class BookDAO {

	@Autowired
	private SqlSession sqlSession;
	
	public ArrayList<BookCopy> selectBookAll() {
		ArrayList<BookCopy> list = (ArrayList)sqlSession.selectList("mapper.book.selectAllBook");
		
		return list;
	}

	public boolean deleteItem(int seq) {
		boolean flag = false;
		int affectedCount = sqlSession.update("mapper.book.deleteBook", seq);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}

	public BookCopy selectBookByBookSeq(int seq) {
		BookCopy bookCopy = (BookCopy)sqlSession.selectOne("mapper.book.selectBookBySeq", seq);
		
		return bookCopy;
	}

	public boolean insertBook(BookCopy copy){
		boolean flag = false;
		
		int affectedCount1 = sqlSession.insert("mapper.book.insertBook", copy);
		int affectedCount2 = sqlSession.insert("mapper.book.insertCopy", copy);
		if (affectedCount1 > 0 && affectedCount2 > 0) {
			flag = true;
		}
		
		return flag;
	}

	public int selectListSize() {
		int size = sqlSession.selectOne("mapper.book.selectListSize");
		
		return size;
	}

	public ArrayList<BookCopy> selectCurrentPageData(int start, int range) {
		ArrayList<BookCopy> list = null;
		HashMap<String, Integer> tmp = new HashMap<String, Integer>();
		tmp.put("start", start);
		tmp.put("range", range);
		
		list = (ArrayList)sqlSession.selectList("mapper.book.selectCurrentPageData", tmp);		

		return list;
	}

}
