package bitedu.bipa.kjw.vo;

import java.sql.Timestamp;

public class BoardVO {
	private int commentId;
	private int parentId;
	private String writer;
	private String password;
	private String content;
	private Timestamp createDate;
	private String attachData;
	private int like;
	private int dislike;
	
	public BoardVO() {
		super();
	}
	
	public BoardVO(int commentId, int parentId, String writer, String password, String content, Timestamp createDate,
			String attachData, int like, int dislike) {
		super();
		this.commentId = commentId;
		this.parentId = parentId;
		this.writer = writer;
		this.password = password;
		this.content = content;
		this.createDate = createDate;
		this.attachData = attachData;
		this.like = like;
		this.dislike = dislike;
	}

	public int getCommentId() {
		return commentId;
	}

	public void setCommentId(int commentId) {
		this.commentId = commentId;
	}

	public int getParentId() {
		return parentId;
	}

	public void setParentId(int parentId) {
		this.parentId = parentId;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Timestamp getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Timestamp createDate) {
		this.createDate = createDate;
	}

	public String getAttachData() {
		return attachData;
	}

	public void setAttachData(String attachData) {
		this.attachData = attachData;
	}

	public int getLike() {
		return like;
	}

	public void setLike(int like) {
		this.like = like;
	}

	public int getDislike() {
		return dislike;
	}

	public void setDislike(int dislike) {
		this.dislike = dislike;
	}

	@Override
	public String toString() {
		return "BoardVO [commentId=" + commentId + ", parentId=" + parentId + ", writer=" + writer + ", password="
				+ password + ", content=" + content + ", createDate=" + createDate + ", attachData=" + attachData
				+ ", like=" + like + ", dislike=" + dislike + "]";
	}
			
}
