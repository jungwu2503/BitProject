package bitedu.bipa.kjw.vo;

import java.util.ArrayList;

public class PageData<T> {
	private ArrayList<T> list;
	private String navBar;
	private int currentPage;

	public PageData(ArrayList<T> list, String navBar, String page) {
		this.list = list;
		this.navBar = navBar;
		page = page==null?"1":page;
		this.currentPage = Integer.parseInt(page);
	}
	public ArrayList<T> getList() {
		return list;
	}
	public void setList(ArrayList<T> list) {
		this.list = list;
	}
	
	public String getNavBar() {
		return navBar;
	}
	public void setNavBar(String navBar) {
		this.navBar = navBar;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	@Override
	public String toString() {
		return "PageData [list=" + list + ", navBar=" + navBar + ", currentPage=" + currentPage + "]";
	}

}