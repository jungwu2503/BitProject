package bitedu.bipa.kjw.dao;

import java.sql.SQLException;
import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bitedu.bipa.kjw.vo.BookCopy;
import bitedu.bipa.kjw.vo.User;

@Repository("memberDAO")
public class MemberDAO {
	
	@Autowired
	private SqlSession sqlSession;
		
	public User selectIdAndPassword(User user) {
		User tmp = sqlSession.selectOne("mapper.user.selectIdForValidate", user);
		
		return tmp;
	}

	public ArrayList<User> selectMemberAll() {
		ArrayList<User> list = (ArrayList)sqlSession.selectList("mapper.user.selectUserAll");
		
		return list;
	}

	public boolean insertUser(User user) {
		boolean flag = false;
		int affectedCount = sqlSession.insert("mapper.user.insertUser", user);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}
	
}

