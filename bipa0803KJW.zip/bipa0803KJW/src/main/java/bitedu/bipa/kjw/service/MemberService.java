package bitedu.bipa.kjw.service;

import java.sql.SQLException;
import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bitedu.bipa.kjw.dao.MemberDAO;
import bitedu.bipa.kjw.vo.User;

@Service("memberService")
public class MemberService {

	@Autowired
	private MemberDAO memberDAO;
	
	public boolean validateId(User user) throws SQLException {
		User tmp = memberDAO.selectIdAndPassword(user);
				
		if (user.getUserId().equals(tmp.getUserId()) && user.getPwd().equals(tmp.getPwd())) return true;
		
		return false;
	}

	public ArrayList<User> getMemberList() {
		ArrayList<User> list = memberDAO.selectMemberAll();
		
		return list;
	}

	public boolean registUser(User user) {
		boolean flag = memberDAO.insertUser(user);
		
		return flag;
	}
	
}
