package bitedu.bipa.kjw.service;

import java.io.File;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.fileupload.FileItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bitedu.bipa.kjw.dao.BoardDAO;
import bitedu.bipa.kjw.utils.PageInfo;
import bitedu.bipa.kjw.utils.PagingbarGenerator;
import bitedu.bipa.kjw.vo.BoardDTO;
import bitedu.bipa.kjw.vo.BoardVO;
import bitedu.bipa.kjw.vo.BookCopy;
import bitedu.bipa.kjw.vo.PageData;
import bitedu.bipa.kjw.vo.BoardVO;

@Service("boardService")
public class BoardService {
	
	@Autowired
	private BoardDAO boardDAO;
	
	public List<BoardVO> getBoardList(){
		List<BoardVO> list = null;
		try {
			list = boardDAO.findAll();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	public boolean saveItem(BoardVO board) {
		boolean flag = false;
		try {
			flag = boardDAO.insertBoard(board);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return flag;
	}

	public boolean removeItem(int seq) {
		boolean flag = false;
		try {
			flag = boardDAO.deleteItem(seq);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return flag;
	}

	public BoardVO findItem(int commentId) {
		BoardVO board = null;
		try {
			//boardDAO.updateCount(commentId);
			board = boardDAO.selectItem(commentId);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return board;
	}

	public boolean updateItem(BoardVO board) {
		// TODO Auto-generated method stub
		boolean flag = false;
		try {
			flag = boardDAO.updateItem(board);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	}

	public BoardVO upload(List<FileItem> items) throws Exception {
		BoardVO board = null;
		board = new BoardVO();
		for(FileItem item : items) {
			if(item!=null&item.isFormField()) {
				String fieldName = item.getFieldName();
				if(fieldName.equals("commentId")) {
					board.setCommentId(Integer.parseInt(item.getString("UTF-8")));
				} else if(fieldName.equals("parentId")) {
					board.setParentId(Integer.parseInt(item.getString("UTF-8")));
				} else if(fieldName.equals("content")) {
					board.setContent(item.getString("UTF-8"));
				} else if(fieldName.equals("writer")) {
					board.setWriter(item.getString("UTF-8"));
				} else if(fieldName.equals("password")) {
					board.setPassword(item.getString("UTF-8"));
				} else if(fieldName.equals("createDate")) {
					board.setCreateDate(new Timestamp(System.currentTimeMillis()));
				} else if(fieldName.equals("like")) {
					board.setLike(Integer.parseInt(item.getString("UTF-8")));
				} else if(fieldName.equals("dislike")) {
					board.setDislike(Integer.parseInt(item.getString("UTF-8")));
				}
			} else {
				String fieldName = item.getFieldName();
				if(fieldName.equals("attachedData")) {
					String temp = item.getName();
					int index = temp.lastIndexOf("\\");
					String fileName = temp.substring(index+1);
					if(fileName!=null&&!fileName.equals("")) {
						board.setAttachData(fileName);
						File uploadFile = new File("C:\\Users\\jungw\\Desktop"+fileName);
						item.write(uploadFile);
					}
				}
			}
		}
		return board;
	}

	public BoardDTO homeUpload(List<FileItem> items) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean homeSaveItem(BoardDTO board) {
		// TODO Auto-generated method stub
		return false;
	}
	
	public PageData<BoardVO> getPageData(int itemsPerPage, String group, String page) {
		
		int listSize = boardDAO.selectListSize();
		page = page == null?"1":page;
		group = group == null?"1":group;
		//PageInfo pageInfo = new PageInfo(itemsPerPage, groupsPerPage, listSize);
		PageInfo pageInfo = new PageInfo(5, 5, listSize);
		int startIndex = pageInfo.calcuOrderOfPage(page);
		
		ArrayList<BoardVO> listForShow = boardDAO.selectCurrentPageData(startIndex, itemsPerPage);
		
		PagingbarGenerator pGenerator = new PagingbarGenerator();
		String navBar = pGenerator.generatePagingInfo(Integer.parseInt(group), Integer.parseInt(page),
							pageInfo);
		
		return new PageData<BoardVO>(listForShow, navBar, page);
	}

	public boolean likeUpdate(int like) {
		boolean flag = false;
		flag = boardDAO.updateLike(like);
		return flag;
	}
	
	public boolean dislikeUpdate(int like) {
		boolean flag = false;
		flag = boardDAO.updateLike(like);
		return flag;
	}
}






