package bitedu.bipa.kjw.service;

import java.io.File;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.fileupload.FileItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bitedu.bipa.kjw.dao.BookDAO;
import bitedu.bipa.kjw.utils.PageInfo;
import bitedu.bipa.kjw.utils.PagingbarGenerator;
import bitedu.bipa.kjw.vo.BookCopy;
import bitedu.bipa.kjw.vo.PageData;

@Service("bookService")
public class BookService {
	
	@Autowired
	private BookDAO bookDAO;
	
	public ArrayList<BookCopy> searchBookAll() {
		ArrayList<BookCopy> list = bookDAO.selectBookAll();
		
		return list;
	}

	public boolean removeItem(int seq) {
		boolean flag = false;
		flag = bookDAO.deleteItem(seq);
		
		return flag;
	}

	public BookCopy getBookDetail(int seq) {
		BookCopy bookCopy = new BookCopy();
		bookCopy = bookDAO.selectBookByBookSeq(seq);
		
		return bookCopy;
	}

	public BookCopy upload(List<FileItem> items) throws Exception {
		BookCopy copy = null;
		copy = new BookCopy();
		for(FileItem item : items) {
			if(item!=null&item.isFormField()) {
				String fieldName = item.getFieldName();
				if (fieldName.equals("book_seq")) {
					copy.setBookSeq(Integer.parseInt(item.getString("UTF-8")));
				} else if (fieldName.equals("isbn")) {
					copy.setIsbn(item.getString("UTF-8"));
				} else if (fieldName.equals("book_title")) {
					copy.setTitle(item.getString("UTF-8"));
				} else if (fieldName.equals("author")) {
					copy.setAuthor(item.getString("UTF-8"));
				} else if (fieldName.equals("publisher")) {
					copy.setPublisher(item.getString("UTF-8"));
				} else if (fieldName.equals("publish_date")) {
					String date = item.getString("UTF-8");
					SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
					try {
						Date now = df.parse(date);
						copy.setPublishDate(new Timestamp(now.getTime()));
					} catch (ParseException e) {
						e.printStackTrace();
					}
				} else if (fieldName.equals("book_position")) {
					copy.setBookPosition(item.getString("UTF-8"));
				} else if (fieldName.equals("book_status")) {
					copy.setBookStaus(item.getString("UTF-8"));
				}
			} else {
				String fieldName = item.getFieldName();
				if(fieldName.equals("book_image")) {
					String temp = item.getName();
					System.out.println("book_image "+temp);
					int index = temp.lastIndexOf("\\");
					String fileName = temp.substring(index+1);
					copy.setBookImage(fileName);
					File uploadFile = new File("C:\\Users\\jungw\\Desktop\\travelImages\\"+fileName);
					item.write(uploadFile);
				}
			}
		}
		return copy;
	}

	public boolean registBook(BookCopy copy) {
		boolean flag = false;
		flag = bookDAO.insertBook(copy);
		return flag;
	}

	public PageData<BookCopy> getPageData(int itemsPerPage, String group, String page) {
		
		int listSize = bookDAO.selectListSize();
		page = page == null?"1":page;
		group = group == null?"1":group;
		//PageInfo pageInfo = new PageInfo(itemsPerPage, groupsPerPage, listSize);
		PageInfo pageInfo = new PageInfo(5, 5, listSize);
		int startIndex = pageInfo.calcuOrderOfPage(page);
		
		ArrayList<BookCopy> listForShow = bookDAO.selectCurrentPageData(startIndex, itemsPerPage);
		
		PagingbarGenerator pGenerator = new PagingbarGenerator();
		String navBar = pGenerator.generatePagingInfo(Integer.parseInt(group), Integer.parseInt(page),
							pageInfo);
		
		return new PageData<BookCopy>(listForShow, navBar, page);
	}
	
}
