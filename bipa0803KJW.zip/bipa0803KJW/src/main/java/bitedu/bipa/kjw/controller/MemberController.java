package bitedu.bipa.kjw.controller;

import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import bitedu.bipa.kjw.service.MemberService;
import bitedu.bipa.kjw.vo.User;

@Controller("memberController")
@RequestMapping("/member")
public class MemberController {

	@Autowired
	private MemberService memberService;
	
	@RequestMapping(value="/list.do", method=RequestMethod.GET)
	public ModelAndView list() {
		ModelAndView mav = null;
		mav = new ModelAndView();
		ArrayList<User> memberList = memberService.getMemberList();
		mav.addObject("data", memberList);
		mav.setViewName("/member/memberList");
		return mav;
	}
	@ResponseBody
	@RequestMapping(value="/listSearch.do", method=RequestMethod.GET)
	public ArrayList<User> listSearch() {
		ArrayList<User> memberList = memberService.getMemberList();
		return memberList;
	}
	
	@RequestMapping(value="/aboutSLion.do", method=RequestMethod.GET)
	public ModelAndView introduceSLion() {
		ModelAndView mav = null;
		mav = new ModelAndView();
		mav.setViewName("/member/aboutSLion");
		return mav;
	}
	
	@RequestMapping(value="/viewRegist.do", method=RequestMethod.GET)
	public ModelAndView viewRegist() {
		ModelAndView mav = null;
		mav = new ModelAndView();
//		mav.addObject("data","MemberList");
		mav.setViewName("/member/user_regist");
		return mav;
	}
	
	@RequestMapping(value="/viewLogin.do", method=RequestMethod.GET)
	public ModelAndView viewLogin() {
		ModelAndView mav = null;
		mav = new ModelAndView();
//		mav.addObject("data","LoginForm");
		mav.setViewName("/member/loginForm");
		return mav;
	}
	
	@RequestMapping(value="/logout.do", method=RequestMethod.GET)
	public ModelAndView logout(HttpSession session) {
		ModelAndView mav = null;
		mav = new ModelAndView();
		session.invalidate();
		mav.setViewName("main");
		return mav;
	}
	
	@RequestMapping(value="/login.do", method=RequestMethod.POST)
	public ModelAndView login(@RequestParam("id") String id, 
			@RequestParam("pass") String pass, HttpSession session) throws SQLException {
		ModelAndView mav = null;
		mav = new ModelAndView();
		String url = "/member/loginForm";
		
		User user = new User(id,pass);
		if(memberService.validateId(user)) {
			session.setAttribute("user", user);
			url = "main";
			System.out.println("Succeed");
		} 
		
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/userRegist.do", method=RequestMethod.POST)
	public ModelAndView userRegist(HttpSession session) throws SQLException {
		ModelAndView mav = null;
		mav = new ModelAndView();
		String url = "/member/user_regist";
		
		String userId = (String) session.getAttribute("user_id");				
		String pwd = (String) session.getAttribute("pwd");
//		String name = (String) session.getAttribute("user_name");
//		String[] address = new String[3];
//		address[0] = (String) session.getAttribute("zipcode");
//		address[1] = (String) session.getAttribute("addr1");
//		address[2] = (String) session.getAttribute("addr2");
//		int[] date = new int[3];
//		date[0] = Integer.parseInt((String)session.getAttribute("year"));
//		date[1] = Integer.parseInt((String)session.getAttribute("month"));
//		date[2] = Integer.parseInt((String)session.getAttribute("days"));
//		char gender = ((String)session.getAttribute("gender")).charAt(0);
//		String[] interests = (String[])session.getValueNames("interests");		
//		String introduction = (String) session.getAttribute("introduction");
				
		User user = new User(userId, pwd);
		memberService.registUser(user);
				
		mav.setViewName(url);
		return mav;
	}	
	
}
