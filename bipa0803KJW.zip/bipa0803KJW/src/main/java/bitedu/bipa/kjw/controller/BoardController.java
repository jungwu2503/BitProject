package bitedu.bipa.kjw.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import bitedu.bipa.kjw.service.BoardService;
import bitedu.bipa.kjw.vo.BoardVO;
import bitedu.bipa.kjw.vo.BookCopy;
import bitedu.bipa.kjw.vo.PageData;
import bitedu.bipa.kjw.vo.BoardVO;

@Controller("boardController")
@RequestMapping("/guestbook")
public class BoardController {

	@Autowired
	private BoardService boardService;
	
	@RequestMapping(value="/",method=RequestMethod.GET)
	public ModelAndView home() {
		ModelAndView mav = new ModelAndView();
		String url = "redirect:./list.do";
		mav.setViewName(url);
		return mav;
	}
	
	@ResponseBody
	@RequestMapping(value="/checkID",method = RequestMethod.POST)
	public String ajaxCheckID(@RequestParam("id") String id) {
		String result = null;
		
		System.out.println(id);
		result = "false";
		return result;
	}
	
	@RequestMapping(value="/list.do",method= {RequestMethod.GET,RequestMethod.POST})
	public ModelAndView list(@RequestParam(required = false) String group, @RequestParam(required = false) String page, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		String url = "/board/list";
		ArrayList<BoardVO> list = (ArrayList<BoardVO>)boardService.getBoardList();
		mav.addObject("list",list);
		PageData<BoardVO> pData = boardService.getPageData(5, group, page);
		mav.addObject("pData", pData);
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/viewWriteForm.do",method=RequestMethod.GET)
	public ModelAndView viewWrite() {
		ModelAndView mav = new ModelAndView();
		String url = "/board/writeItem";
		
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/write.do",method=RequestMethod.POST)
	public ModelAndView write(@ModelAttribute("board") BoardVO board) {
		ModelAndView mav = new ModelAndView();
		String url = "redirect:./list.do";
		
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/upload.do",method=RequestMethod.POST)
	public ModelAndView upload(HttpServletRequest req) {
		ModelAndView mav = new ModelAndView();
		String url = "redirect:./list.do";
		//upload
		String path = "C:\\Users\\jungw\\Desktop";
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setRepository(new File(path));
		factory.setSizeThreshold(1024*1024*10);
		ServletFileUpload upload = new ServletFileUpload(factory);
		List<FileItem> items = null;
		try {
			items = upload.parseRequest(req);
		} catch (FileUploadException e) {
			e.printStackTrace();
		}
		BoardVO board = null;
		try {
			board = boardService.upload(items);
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println(board.getContent());
		System.out.println(board.getWriter());
		System.out.println(board.getPassword());
		if(!board.getContent().equals("")&&!board.getWriter().equals("")&&!board.getPassword().equals("")) {
			boolean flag = boardService.saveItem(board);
		} else {
			upload = null;
			items = null;
		}
		
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/download.do",method = RequestMethod.GET)
	public void download(@RequestParam("fileName") String fileName,HttpServletResponse resp) {
		File downloadFile = new File("C:\\Users\\jungw\\Desktop"+fileName);
		
		try {
			fileName = new String(fileName.getBytes("UTF-8"),"ISO-8859-1");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		resp.setContentType("text/html; charset=UTF-8");
		resp.setHeader("Cache-Control", "no-cache");
		resp.addHeader("Content-Disposition", "attatchment;filename="+fileName);
		
		try {
			FileInputStream fis = new FileInputStream(downloadFile);
			OutputStream os = resp.getOutputStream();
			byte[] buffer = new byte[256];
			int length = 0;
			while((length=fis.read(buffer))!=-1) {
				os.write(buffer, 0, length);
			}
			os.close();
			fis.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		
	}
	
	@RequestMapping(value="/delete.do",method=RequestMethod.GET)
	public ModelAndView remove(@RequestParam("commentId") int commentId) {
		ModelAndView mav = new ModelAndView();
		String url = "redirect:./list.do";

		boolean flag = boardService.removeItem(commentId);
		
		mav.setViewName(url);
		return mav;
	}
	
//	@RequestMapping(value="/detail.do", method=RequestMethod.GET)
//	public ModelAndView bookDetail(@RequestParam("commentId") int commentId) {
//		ModelAndView mav = null;
//		mav = new ModelAndView();
//		String url = "/board/detail";
//		BoardVO board = boardService.findItem(commentId);
//		mav.addObject("board",board);		
//		mav.setViewName(url);
//
//		return mav;
//	}
	
	//=
	@RequestMapping(value="/search.do",method=RequestMethod.GET)
	public ModelAndView search(@RequestParam("commentId") int commentId) {
		ModelAndView mav = new ModelAndView();
		String url = "./board/detail";

		BoardVO board = boardService.findItem(commentId);
		mav.addObject("board",board);
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/viewUpdateForm.do",method=RequestMethod.POST)
	public ModelAndView viewUpdate(@ModelAttribute("board") BoardVO board) {
		ModelAndView mav = new ModelAndView();
		String url = "./board/update";
		//System.out.print(board);
		mav.addObject("board",board);
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/likeUpdate.do",method=RequestMethod.POST)
	public ModelAndView likeUpdate(@ModelAttribute("like") int like) {
		ModelAndView mav = new ModelAndView();
		String url = "redirect:./list.do";
		
		boolean flag = boardService.likeUpdate(like);
		
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/dislikeUpdate.do",method=RequestMethod.POST)
	public ModelAndView dislikeUpdate(@ModelAttribute("dislike") int dislike) {
		ModelAndView mav = new ModelAndView();
		String url = "redirect:./list.do";
		
		boolean flag = boardService.dislikeUpdate(dislike);
		
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/update.do",method=RequestMethod.POST)
	public ModelAndView update(@ModelAttribute("board") BoardVO board) {
		ModelAndView mav = new ModelAndView();
		String url = "redirect:./list.do";

		boolean flag = boardService.updateItem(board); 
		
		mav.setViewName(url);
		return mav;
	}
}
