package bitedu.bipa.kjw.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import bitedu.bipa.kjw.service.BookService;
import bitedu.bipa.kjw.vo.BookCopy;
import bitedu.bipa.kjw.vo.PageData;
import bitedu.bipa.kjw.vo.User;

@Controller("bookController")
@RequestMapping("/book")
public class BookController {
	
	@Autowired
	private BookService bookService;

	/*@RequestMapping("/list.do")
	public ModelAndView list(HttpSession session) {
		ModelAndView mav = null;
		mav = new ModelAndView();
		String url = "/book/bookList";
		User user = (User)session.getAttribute("user");
		
		ArrayList<BookCopy> list = bookService.searchBookAll();
		if(user.getUserId().equals("admin")) {
			mav.addObject("list", list);
		} else {
			url = "/member/loginForm";
			mav.addObject("data","�����ڰ� �ƴմϴ�.");
		}
		mav.setViewName(url);

		return mav;
	}*/
	
	@RequestMapping(value="view_regist.do", method=RequestMethod.GET)
	public ModelAndView viewRegist() {
		ModelAndView mav = new ModelAndView();
		
		mav.setViewName("/book/bookRegist");
		return mav;
	}
	
	@RequestMapping(value="/list.do", method=RequestMethod.GET)
	public ModelAndView list(@RequestParam(required = false) String group, @RequestParam(required = false) String page, HttpSession session) {
		ModelAndView mav = new ModelAndView();
		String url = "/book/bookList";
		
		User user = (User)session.getAttribute("user");
		
		if(user.getUserId().equals("admin")) {
			PageData<BookCopy> pData = bookService.getPageData(5, group, page);
			mav.addObject("pData", pData);
		} else {
			url = "/member/loginForm";
		}
		mav.setViewName(url);

		return mav;
	}
	
	@ResponseBody
	@RequestMapping(value="/listSearch.do", method=RequestMethod.GET)
	public ArrayList<BookCopy> listSearch() {
		ArrayList<BookCopy> list = bookService.searchBookAll();
		return list;
	}
	
	@RequestMapping(value="/remove.do",method=RequestMethod.GET)
	public ModelAndView remove(@RequestParam("bookSeq") int seq) {
		ModelAndView mav = new ModelAndView();
		String url = "redirect:./list.do";

		boolean flag = bookService.removeItem(seq);
		
		mav.setViewName(url);
		return mav;
	}
	
	@RequestMapping(value="/detail.do", method=RequestMethod.GET)
	public ModelAndView bookDetail(@RequestParam("bookSeq") int seq) {
		ModelAndView mav = null;
		mav = new ModelAndView();
		String url = "/book/bookDetail";
		BookCopy bookCopy = bookService.getBookDetail(seq);
				
		mav.addObject("bookCopy", bookCopy);		
		mav.setViewName(url);

		return mav;
	}
	
	@RequestMapping(value="/upload.do", method=RequestMethod.POST)
	public ModelAndView upload(HttpServletRequest request) {
		ModelAndView mav = new ModelAndView();
		System.out.println("upload");
		String path = "C:\\Users\\jungw\\Desktop";
		DiskFileItemFactory factory = new DiskFileItemFactory();
		factory.setRepository(new File(path));
		factory.setSizeThreshold(1024*1024*10);
		ServletFileUpload upload = new ServletFileUpload(factory);
		List<FileItem> items = null;
		try {
			items = upload.parseRequest(request);
		} catch (FileUploadException e) {
			e.printStackTrace();
		}
		System.out.println(items);
		BookCopy copy = null;
		try {
			copy = bookService.upload(items);
			bookService.registBook(copy);
		} catch (Exception e) {
			e.printStackTrace();
		}
		mav.setViewName("redirect:list.do");
		
		return mav;
	}
	
	
}
