package bitedu.bipa.kjw.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bitedu.bipa.kjw.vo.BoardVO;
import bitedu.bipa.kjw.vo.BookCopy;

@Repository("boardDAO")
public class BoardDAO {
	
	@Autowired
	private SqlSession sqlSession;
	
	public List<BoardVO> findAll() throws SQLException{
		List<BoardVO> list = null;
		list = sqlSession.selectList("mapper.board.selectBoardList");
		//System.out.println(list.size());
		return list;
	}

	public boolean insertBoard(BoardVO board) throws SQLException {
		boolean flag = false;
		int affectedCount = sqlSession.insert("mapper.board.insertBoard", board);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}

	public boolean deleteItem(int seq) throws SQLException {
		boolean flag = false;
		int affectedCount = sqlSession.update("mapper.board.deleteBoard", seq);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}
	
//	public boolean updateCount(int seq) throws SQLException {
//		boolean flag = false;
//		int affectedCount = sqlSession.update("mapper.board.updateCounter", seq);
//		if(affectedCount>0) {
//			flag = true;
//		}
//		return flag;
//	}
	
	public BoardVO selectItem(int seq) throws SQLException {
		BoardVO board = null;
		board = sqlSession.selectOne("mapper.board.findBoard", seq);
		return board;
	}

	public boolean updateItem(BoardVO board) throws SQLException {
		boolean flag = false;
		int affectedCount = sqlSession.update("mapper.board.updateBoard", board);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}
	
	public int selectListSize() {
		int size = sqlSession.selectOne("mapper.board.selectListSize");
		
		return size;
	}

	public ArrayList<BoardVO> selectCurrentPageData(int start, int range) {
		ArrayList<BoardVO> list = null;
		HashMap<String, Integer> tmp = new HashMap<String, Integer>();
		tmp.put("start", start);
		tmp.put("range", range);
		
		list = (ArrayList)sqlSession.selectList("mapper.board.selectCurrentPageData", tmp);		

		return list;
	}

	public boolean updateLike(int like) {
		boolean flag = false;
		int affectedCount = sqlSession.update("mapper.board.updateLike", like);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}

	public boolean updateDislike(int like) {
		boolean flag = false;
		int affectedCount = sqlSession.update("mapper.board.updateDislike", like);
		if(affectedCount>0) {
			flag = true;
		}
		return flag;
	}
}




