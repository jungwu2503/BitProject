$(document).ready(function(){
	$('#go_view_update').on('click',function(){
		alert($('#book_seq').val());
		$('#frm').attr('action','view_update.do?bookSeq='+$('#book_seq').val());
		$('#frm').submit();
	});

	$('#go_book_list').on('click',function(){
		alert('go');
		$('#frm').attr('action','list.do');
		$('#frm').attr('method','get');
		$('#frm').submit();
	});
	
	$('#go_book_regist').on('click',function(){
		$('#frm').attr('action','regist.do');
		$('#publish_date').val($('#publish_date').val()+" 00:00:00");
		$('#frm').submit();
	});

	$('#go_book_update').on('click',function(){
		$('#frm').attr('action','update.do?bookSeq='+$('#book_seq').val());
		$('#publish_date').val($('#publish_date').val()+" 00:00:00");
		$('#frm').submit();
	});
		
	$('#go_comment_regist').on('click',function(){
		alert('댓글이 등록되었습니다.');
		$('#frm').attr('action','regist_comment.do');
		$('#title').val($('#title').val());
		$('#name').val($('#writer').val());
		$('#contents').val($('#contents').val());
		$('#frm').attr('method','post');
		
		$('#frm').submit();
	});
});

	