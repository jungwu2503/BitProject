package bitedu.bipa.book.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bitedu.bipa.book.dao.MemberDAO;
import bitedu.bipa.book.vo.BookCopy;
import bitedu.bipa.book.vo.CommentVO;

@Service("memberService")
public class MemberService {
	
	@Autowired
	private MemberDAO dao;
	
	public boolean registComment(CommentVO comment) {
		boolean flag = false;
		flag = dao.insertComment(comment);
		
		return flag;
	}

	public ArrayList<CommentVO> searchCommentsAll() {
		ArrayList<CommentVO> list = dao.selectCommentsAll();
		
		return list;
	}

	public boolean deleteComment(String no) {
		boolean flag = false;
		flag = dao.deleteComment(Integer.parseInt(no));
		
		return flag;
	}

}
