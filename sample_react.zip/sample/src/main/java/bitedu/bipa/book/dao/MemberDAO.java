package bitedu.bipa.book.dao;

import java.util.ArrayList;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import bitedu.bipa.book.vo.CommentVO;

@Repository("memberDAO")
public class MemberDAO {

	@Autowired
	private SqlSession sqlSession;
	
	public boolean insertComment(CommentVO comment) {
		boolean flag = false;
		
		int affectedCount1 = sqlSession.insert("mapper.comment.insertComment", comment);
		if (affectedCount1 > 0) {
			flag = true;
		}
		
		return flag;
	}

	public ArrayList<CommentVO> selectCommentsAll() {
		ArrayList<CommentVO> list = (ArrayList)sqlSession.selectList("mapper.comment.selectCommentsAll");
		
		return list;
	}

	public boolean deleteComment(int no) {
		boolean flag = false;
		
		int affectedCount1 = sqlSession.insert("mapper.comment.deleteComment", no);
		if (affectedCount1 > 0) {
			flag = true;
		}
		
		return flag;
	}
	
	
}
