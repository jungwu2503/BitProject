package bitedu.bipa.book.dao;

import java.util.ArrayList;

import bitedu.bipa.book.vo.BookCopy;

public class BlmDAO4 implements IBlmDAO {

	@Override
	public boolean insertBook(BookCopy copy) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public ArrayList<BookCopy> selectBookAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteBook(int parseInt) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public BookCopy selectBook(int parseInt) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateBook(BookCopy copy) {
		// TODO Auto-generated method stub
		return false;
	}

}
