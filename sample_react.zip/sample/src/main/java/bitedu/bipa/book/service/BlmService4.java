package bitedu.bipa.book.service;

import java.io.File;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.fileupload.FileItem;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import bitedu.bipa.book.dao.BlmDAO3;
import bitedu.bipa.book.utils.PageInfo;
import bitedu.bipa.book.utils.PagingbarGenerator;
import bitedu.bipa.book.vo.BookCopy;
import bitedu.bipa.book.vo.PageData;

@Service("blmService4")
public class BlmService4 {

	@Autowired
	private BlmDAO3 dao;
	
	public boolean registBook(BookCopy copy) {
		boolean flag = false;
		flag = dao.insertBook(copy);
		return flag;
	}
	
	public ArrayList<BookCopy> searchBookAll(){
		ArrayList<BookCopy> list = null;
		list = dao.selectBookAll();
		return list;
	}
	public boolean removeBook(String bookSeq) {
		boolean flag = false;
		flag = dao.deleteBook(Integer.parseInt(bookSeq));
		return flag;
	}
	public BookCopy findBook(String bookSeq) {
		BookCopy copy = null;
		copy = dao.selectBook(Integer.parseInt(bookSeq));
		System.out.println(copy);
		return copy;
	}
	public boolean modifyBook(BookCopy copy) {
		boolean flag = false;
		flag = dao.updateBook(copy);
		return flag;
	}
	
	public BookCopy upload(List<FileItem> items) throws Exception {
		BookCopy copy = null;
		copy = new BookCopy();
		for(FileItem item : items) {
			if(item!=null&item.isFormField()) {
				//�Ϲ����� Form�� ����
				String fieldName = item.getFieldName();
				if (fieldName.equals("book_seq")) {
					copy.setBookSeq(Integer.parseInt(item.getString("UTF-8")));
				} else if (fieldName.equals("isbn")) {
					copy.setIsbn(item.getString("UTF-8"));
				} else if (fieldName.equals("book_title")) {
					copy.setTitle(item.getString("UTF-8"));
				} else if (fieldName.equals("author")) {
					copy.setAuthor(item.getString("UTF-8"));
				} else if (fieldName.equals("publisher")) {
					copy.setPublisher(item.getString("UTF-8"));
				} else if (fieldName.equals("publish_date")) {
					String date = item.getString("UTF-8");
					SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
					try {
						Date now = df.parse(date);
						copy.setPublishDate(new Timestamp(now.getTime()));
					} catch (ParseException e) {
						e.printStackTrace();
					}
				} else if (fieldName.equals("book_position")) {
					copy.setBookPosition(item.getString("UTF-8"));
				} else if (fieldName.equals("book_status")) {
					copy.setBookStaus(item.getString("UTF-8"));
				}
			} else {
				// upload�� �����Ϳ� ���� ���� ����
				String fieldName = item.getFieldName();
				if(fieldName.equals("book_image")) {
					String temp = item.getName();
					System.out.println("book_image "+temp);
					int index = temp.lastIndexOf("\\");
					String fileName = temp.substring(index+1);
					copy.setBookImage(fileName);
					File uploadFile = new File("C:\\Users\\jungw\\Desktop\\travelImages\\"+fileName);
					item.write(uploadFile);
				}
			}
		}
		return copy;
	}

	public PageData<BookCopy> getPageData(int itemsPerPage, String group, String page) {
		
		int listSize = dao.selectListSize();
		page = page == null?"1":page;
		group = group == null?"1":group;
		//PageInfo pageInfo = new PageInfo(itemsPerPage, groupsPerPage, listSize);
		PageInfo pageInfo = new PageInfo(5, 2, listSize);
		int startIndex = pageInfo.calcuOrderOfPage(page);
		
		ArrayList<BookCopy> listForShow = dao.selectCurrentPageData(startIndex, itemsPerPage);
		//System.out.println(listForShow);	
		
		PagingbarGenerator pGenerator = new PagingbarGenerator();
		String navBar = pGenerator.generatePagingInfo(Integer.parseInt(group), Integer.parseInt(page),
							pageInfo);
		
		return new PageData<BookCopy>(listForShow, navBar, page);
	}
	
}







