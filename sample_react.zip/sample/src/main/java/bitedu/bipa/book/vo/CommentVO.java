package bitedu.bipa.book.vo;

import java.sql.Date;

public class CommentVO {
	private int no;
	private String title;
	private String contents;
	private String writer;
	private int views;
	private Date cTime;
	
	public CommentVO() {
		
	}
	
	public CommentVO(int no, String title, String contents, String writer, int views, Date cTime) {
		super();
		this.no = no;
		this.title = title;
		this.contents = contents;
		this.writer = writer;
		this.views = views;
		this.cTime = cTime;
	}

	public int getNo() {
		return no;
	}

	public void setNo(int no) {
		this.no = no;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContents() {
		return contents;
	}

	public void setContents(String contents) {
		this.contents = contents;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public int getviews() {
		return views;
	}

	public void setviews(int views) {
		this.views = views;
	}

	public Date getcTime() {
		return cTime;
	}

	public void setcTime(Date cTime) {
		this.cTime = cTime;
	}

	@Override
	public String toString() {
		return "CommentVO [no=" + no + ", title=" + title + ", contents=" + contents + ", writer=" + writer + ", views="
				+ views + ", cTime=" + cTime + "]";
	}
			
}
